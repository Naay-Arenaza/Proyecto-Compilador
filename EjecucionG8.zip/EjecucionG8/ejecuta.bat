@echo off
cd /d "%~dp0"
java -jar Proyecto-Compilador.jar TxtPrueba.txt
pause
